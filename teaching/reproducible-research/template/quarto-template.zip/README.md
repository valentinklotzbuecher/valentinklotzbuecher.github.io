# Quarto template for seminar papers and theses at University of Freiburg

## Instructions

- Start a new project in RStudio in a folder containing the files listed below
- Adjust name, title, chapters in YML file
- Go to RStudio Terminal and enter "quarto render"
- Output documents will be saved in the folder "docs"

## Files

- `_quarto.yml`: basic project and author information, HTML and PDF setup
- `include-in-header.tex`: LaTeX settings and packages
- `before_body.tex`: PDF title page with logo (`UFR_Siegel_Blau.png`, `UFR_Wortmarke.pdf`)
- `index.qmd`: Introduction/first chapter and start page (do not rename)
- `main.qmd`: The main part, replace with separate chapters as needed 
- `references.qmd`: References from `references.bib` and`grateful_refs.bib` 
- `the-quarterly-journal-of-economics.csl`: Citation style language

