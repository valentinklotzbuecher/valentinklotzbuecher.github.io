# Introductory slides

From the seminar *Reproducible Research Pipelines with R and Quarto*,
University of Freiburg, winter term 2024/25 (16 October 2024).
Valentin Klotzbücher.

Organisation of the seminar, software, references and assignments, as RevealJS slides.

## Files

- `seminar2024_introslides.qmd`: the slides
- `custom.scss`: slide theme
- `seminar2024.bib`: references
- `the-quarterly-journal-of-economics.csl`: citation style

## Rendering

Open the folder as an RStudio project, or in a terminal run:

```bash
quarto render seminar2024_introslides.qmd
```
