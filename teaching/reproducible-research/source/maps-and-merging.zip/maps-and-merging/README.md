# Tutorial 3: Maps and merging data

From the seminar *Reproducible Research Pipelines with R and Quarto*,
University of Freiburg, winter term 2024/25 (6 and 13 November 2024).
Valentin Klotzbücher.

Geospatial data in R: reshaping, map projections, static maps with ggplot2 and sf, an interactive leaflet map, file formats, and three ways of merging conflict events with migration data (names, fuzzy matching, spatial join). The slides were built up over two sessions; this is the final version.

## Files

- `chapter4.qmd`: the slides, with all code
- `chapter4_share.qmd`: the starter file used for live coding
- `custom.scss`: slide theme
- `references.bib`: references
- `the-quarterly-journal-of-economics.csl`: citation style

## Data

The data are not included. Before rendering, download:

- **Migration data** from Niva et al. (2023), "World's human migration patterns
  in 2000-2019 unveiled by high-resolution data", *Nature Human Behaviour*.
  Download from Zenodo, <https://doi.org/10.5281/zenodo.7997134>, and put
  `masterData.rds` and `admGeoms.rds` into `data/Niva2023/`.
- **Conflict events** from the UCDP Georeferenced Event Dataset (GED), global
  version 24.1. Download the CSV from <https://ucdp.uu.se/downloads/> and save
  it as `data/UCDP/GEDEvent_v24_1.csv`.

## Rendering

You need R, Quarto and these R packages:

```r
install.packages(c("arrow", "flextable", "gridExtra", "here", "janitor", "leaflet", "modelsummary", "purrr", "RColorBrewer", "readxl", "sf", "sp", "stringdist", "tidyverse"))
```

Open the folder as an RStudio project, or in a terminal run:

```bash
quarto render chapter4.qmd --to revealjs
```
