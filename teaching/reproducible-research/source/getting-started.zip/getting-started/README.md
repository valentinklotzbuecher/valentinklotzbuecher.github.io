# Tutorial 1: Getting started with data wrangling and reporting

From the seminar *Reproducible Research Pipelines with R and Quarto*,
University of Freiburg, winter term 2024/25 (16 October 2024).
Valentin Klotzbücher.

Setting up an RStudio project and a first Quarto report: citations, data cleaning with the tidyverse, a summary table, a figure, cross-references and inline results.

## Files

- `chapter_1.qmd`: the handout, with all steps and code
- `tutorial1_share.qmd`: the starter file used for live coding
- `seminar2024.bib`, `grateful-refs.bib`: references
- `the-quarterly-journal-of-economics.csl`: citation style

## Data

The data are not included. Before rendering, download:

- **Migration data** from Niva et al. (2023), "World's human migration patterns
  in 2000-2019 unveiled by high-resolution data", *Nature Human Behaviour*.
  Download from Zenodo, <https://doi.org/10.5281/zenodo.7997134>, and put
  `masterData.rds` into `data/Niva2023/`.

## Rendering

You need R, Quarto and these R packages:

```r
install.packages(c("grateful", "here", "janitor", "modelsummary", "tidyverse"))
```

Open the folder as an RStudio project, or in a terminal run:

```bash
quarto render chapter_1.qmd
```
