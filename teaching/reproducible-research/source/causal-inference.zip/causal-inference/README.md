# Tutorial 5: Causal inference basics, by simulation

From the seminar *Reproducible Research Pipelines with R and Quarto*,
University of Freiburg, winter term 2024/25 (20 November 2024).
Valentin Klotzbücher.

A Quarto book project. Part 1 simulates confounders, colliders and mediators and shows what controlling for each does to an estimate; part 2 uses rainfall as an instrument for income and then breaks the exclusion restriction.

## Files

- `_quarto.yml`: book set-up for HTML and PDF
- `index.qmd`, `part_1.qmd`, `part_2.qmd`, `references.qmd`: the chapters
- `DAGs.qmd`, `DAG*.JPG`: the causal diagrams and their Graphviz source
- `before-body.tex`, `include-in-header.tex`, `UFR_*`: PDF title page and LaTeX settings
- `the-quarterly-journal-of-economics.csl`: citation style

## Rendering

You need R, Quarto and these R packages:

```r
install.packages(c("AER", "broom", "glue", "grateful", "janitor", "kableExtra", "modelsummary", "tidyverse"))
```

Open the folder as an RStudio project, or in a terminal run:

```bash
quarto render
```
