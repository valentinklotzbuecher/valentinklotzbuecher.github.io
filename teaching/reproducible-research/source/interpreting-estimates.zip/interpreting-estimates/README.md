# Tutorial 6: Interpreting estimation results

From the seminar *Reproducible Research Pipelines with R and Quarto*,
University of Freiburg, winter term 2024/25 (18 December 2024).
Valentin Klotzbücher.

P-values, S-values, equivalence tests and confidence intervals, illustrated with simulated data.

## Files

- `tutorial6slides.qmd`: the slides, with all code
- `custom.scss`: slide theme
- `references.bib`: references
- `the-quarterly-journal-of-economics.csl`: citation style

## Rendering

You need R, Quarto and these R packages:

```r
install.packages(c("broom", "ggplot2", "modelsummary", "tidyverse"))
```

Open the folder as an RStudio project, or in a terminal run:

```bash
quarto render tutorial6slides.qmd
```
