# Tutorial 2: One report, three formats

From the seminar *Reproducible Research Pipelines with R and Quarto*,
University of Freiburg, winter term 2024/25 (30 October 2024).
Valentin Klotzbücher.

A short report on global migration data, rendered to HTML, PDF and Word from one source, with a static and an interactive figure.

## Files

- `chapter_2.qmd`: the report
- `chapter2-share.qmd`: the starter file used for live coding
- `references.bib`: references
- `the-quarterly-journal-of-economics.csl`: citation style

## Data

The data are not included. Before rendering, download:

- **Migration data** from Niva et al. (2023), "World's human migration patterns
  in 2000-2019 unveiled by high-resolution data", *Nature Human Behaviour*.
  Download from Zenodo, <https://doi.org/10.5281/zenodo.7997134>, and put
  `masterData.rds` into `data/Niva2023/`.

## Rendering

You need R, Quarto and these R packages:

```r
install.packages(c("here", "janitor", "modelsummary", "plotly", "tidyverse"))
```

Open the folder as an RStudio project, or in a terminal run:

```bash
quarto render chapter_2.qmd
```
